<template>
  <div>
    <div style="width: 400px;height:300px;background: yellow;">轮播图</div>
    File
    <ul>
      <li>正在热映</li>
      <li>即将上线</li>
      <router-view></router-view>
    </ul>
    </div>
</template>
