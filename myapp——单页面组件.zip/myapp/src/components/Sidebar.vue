<template>
    <div>
        <ul>
            <li>1111</li>
            <li>2222</li>
            <li>3333</li>
        </ul>
    </div>
</template>

<style scoped>
li {
    background-color: #00f;
}
</style>
