<template>
    <div>Center</div>
</template>
